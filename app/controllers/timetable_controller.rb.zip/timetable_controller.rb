class TimetableController < ApplicationController
  layout "mindcom"
  before_filter :login_required
  def weekday_index
     @class_id=MgCourse.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id],:mg_wing_id=>1).pluck(:id)
    #@batches = MgBatch.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id],:mg_course_id=>@class_id)
     @allvalue=["0","1","2","3","4","5","6"]
    @weekdaychecked=[]#MgWeekday.where(:mg_wing_id=>nil,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:weekday)
    @schoolWings=MgWing.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:wing_name,:id)
  end
  
  def index
   @academic_name=MgTimeTable.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name,:id)
    #@batch=MgBatch.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
    @weekDays=MgClassTiming.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name,:id)

  end

  def create
    MgWeekday.transaction do
    @wing_id=params[:mg_wing_id]
    if @wing_id==""
      @wing_id=nil
    else
      @wing_id=params[:mg_wing_id]
    end

    # @wing_id=params[:mg_wing_id]
    @checked_week_day_id=params[:checked_weekday]
    @checked_weeks=@checked_week_day_id.split(",")

    #This for updating the is_deleted=0 and creating new record
    for i in 0...@checked_weeks.size
       @checked_weekday=MgWeekday.where(:mg_wing_id=>@wing_id,:weekday=>@checked_weeks[i],:mg_school_id=>session[:current_user_school_id])
       if @checked_weekday.size<1
          @checked=MgWeekday.new()
          # @checked.mg_batch_id=@wing_id
          @checked.weekday=@checked_weeks[i]
          @checked.is_deleted=0
          @checked.mg_school_id=session[:current_user_school_id]
          @checked.day_of_week=@checked_weeks[i]
          @checked.mg_wing_id=@wing_id
          @checked.save
     else
        @checked_weekday[0].update(:is_deleted=>0)
      end
      
    end

    #This for updating the is_deleted=1
    @unchecked_week_day_id=params[:unchecked_weekday]
    @unchecked_weeks=@unchecked_week_day_id.split(",")
    for i in 0... @unchecked_weeks.size
       @unchecked_weekday=MgWeekday.where(:mg_wing_id=>@wing_id,:weekday=>@unchecked_weeks[i])
        if @unchecked_weekday.size>0
          @unchecked_weekday[0].update(:is_deleted=>1)
        end
    end
  end
  end

  def show
    @wing_id=params[:mg_wing_id]
    if @wing_id==""
      @wing_id=nil
    else
      @wing_id=params[:mg_wing_id]
    end
    @allvalue=["0","1","2","3","4","5","6"]
    @weekdaychecked=MgWeekday.where(:mg_wing_id=>@wing_id,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:weekday)
   puts "checked_days in show for default"
   puts @weekdaychecked
    render :layout => false
  end



  def show_batch_timetables

    # timeTableEntries=MgTimeTableEntry.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
    # @displayTimeTable="<table class='disply-all-timeTable-tbl-div' cellpadding='0' cellspacing='0'>"

    # finalArray=Array.new
    # weekDayHash=Hash.new
    # weekDayHash[0]='Sunday'
    # weekDayHash[1]="Monday"
    # weekDayHash[2]="Tuesday"
    # weekDayHash[3]="Wednesday"
    # weekDayHash[4]="Thursday"
    # weekDayHash[5]="Friday"
    # weekDayHash[6]="Saturday"

    # puts weekDayHash[0]
    # if timeTableEntries.present?
    #   timeTableEntries.each_with_index do|timeTableEntry, index|
    #       weekDayObj= timeTableEntry.mg_weekday 
    #       batchObj= timeTableEntry.mg_batch 
    #       subjectObj= timeTableEntry.mg_subject 
    #       employeeObj= timeTableEntry.mg_employee   
    #       classTimingObj=MgClassTiming.find(timeTableEntry.mg_class_timings_id)

    #       combinedHash=Hash.new

    #       if weekDayObj.present?
    #         combinedHash[:week_day_id]=weekDayObj.day_of_week
    #         combinedHash[:week_day_name]=weekDayHash[weekDayObj.day_of_week]
    #       else
    #         combinedHash[:week_day_id]=nil
    #         combinedHash[:week_day_name]=''
    #       end

    #       if classTimingObj.present?
    #         startTime = classTimingObj.start_time.strftime("%k:%M%p")
    #         endTime   = classTimingObj.end_time.strftime("%k:%M%p")
    #         combinedHash[:class_timing_id]=classTimingObj.id
    #         combinedHash[:start_time]=startTime
    #         combinedHash[:end_time]=endTime
            
    #       else
    #         combinedHash[:class_timing_id]=''
    #         combinedHash[:start_time]=''
    #         combinedHash[:end_time]=''
            
    #       end

    #       if batchObj.present?
    #         combinedHash[:batch_id]= batchObj.id
    #         combinedHash[:batch_name]=batchObj.course_batch_name
    #       else
    #         combinedHash[:batch_id]= ''
    #         combinedHash[:batch_name]=''
    #       end

    #       if subjectObj.present?
    #         combinedHash[:subject_id]= subjectObj.id
    #         combinedHash[:subject_name]=subjectObj.subject_name
    #       else
    #         combinedHash[:subject_id]= ''
    #         combinedHash[:subject_name]=''
    #       end

    #       if employeeObj.present?
    #         combinedHash[:employee_id]= employeeObj.id
    #         combinedHash[:employee_name]=employeeObj.first_name
    #       else
    #         combinedHash[:employee_id]= ''
    #         combinedHash[:employee_name]=''
    #       end
    #       finalArray<<combinedHash
    #   end
    # end
    # #weekDays.sort! { |a,b| a.day_of_week <=> b.day_of_week }
    # #finalArray.sort! {|a,b| a[:day_of_week] <=> b[:day_of_week]}
    # finalArray.sort! { |a, b| [a[:batch_id], a[:week_day_id], a[:start_time]] <=> [b[:batch_id], b[:week_day_id], b[:start_time]] }
    # #finalArray.sort! { |a, b| [a[:week_day_id], a[:batch_id], a[:start_time]] <=> [b[:week_day_id], b[:batch_id], b[:start_time]] }
    
    # # return_keys = [ :batch_id]
    # # batch_id_array = finalArray.collect do |event|
    # #   Hash[
    # #     return_keys.collect do |key|
    # #       [ key, event[key] ]
    # #     end
    # #   ]
    # # end

    # #hsh=finalArray.select { |a| a[ :batch_id]== a[ :batch_id] }
    # #puts "hsh"
    # #puts hsh

    # periodTimingHash=Hash.new
    # for i in 0...8
    #   if finalArray.size>=8
    #     sTime=finalArray[i][:start_time]
    #     eTime=finalArray[i][:end_time]
    #     periodTimingHash[i]="#{sTime}-#{eTime}"
    #   end
    # end

    # testBatch=0
    # testWeek="abc"
    # closeTR="No"
    # currentDay=""
    # displayTimeTableRow=""
    # @displayTimeTableWeekName=""
    # @displayTimeTableTiming=""
    # count=0
    # s_time=""
    # e_time=""
    # for i in 0...finalArray.size
    #   # if i==0
    #   #   @displayTimeTable +="<tr class='tbl-tr'>"
    #   #   finalArray[i].each do |key, value|
    #   #     @displayTimeTable +="<td class='tbl-td' >#{key} </td>"
    #   #   end
    #   #   @displayTimeTable +="</tr>"
    #   # end

    #   # @displayTimeTable +="<tr class='tbl-tr'>"
    #   # finalArray[i].each do |key, value|
    #   #   @displayTimeTable +="<td class='tbl-td' >#{value} </td>"
    #   # end
    #   # @displayTimeTable +="</tr>"

    #   checkBatch=finalArray[i][:batch_id]
    #   weekDayName=finalArray[i][:week_day_name]
    #   startTime=finalArray[i][:start_time]
    #   endTime=finalArray[i][:end_time]
    #   batchName=finalArray[i][:batch_name]
    #   subjectName=finalArray[i][:subject_name]
    #   employeeName=finalArray[i][:employee_name] 

    #   if i==0
    #     testBatch=checkBatch
    #     testWeek=weekDayName
    #     #first tr of the table

    #     # @displayTimeTable +="<tr class='tbl-tr'> 
    #     #           <td class='tbl-td' ></td>
    #     #           <td class='tbl-td' colspan='8' align='center'>Monday</td>
    #     #           <td class='tbl-td' colspan='8' align='center'>Tuesday</td>
    #     #           <td class='tbl-td' colspan='8' align='center'>Wednesday</td>
    #     #           <td class='tbl-td' colspan='8' align='center'>Thursday</td>
    #     #           <td class='tbl-td' colspan='8' align='center'>Friday</td>
    #     #           <td class='tbl-td' colspan='8' align='center'>Saturday</td>
    #     #           </tr>"

    #     @displayTimeTable +="<tr class='tbl-tr'> <th class='tbl-td'></th>"
    #     for i in 1...7
    #       @displayTimeTable +="<th class='tbl-td mg-align-center mg-tbl-padding-mod' colspan='8'>#{weekDayHash[i]}</th>"
    #     end
    #     @displayTimeTable +="</tr> "

    #     @displayTimeTable +="<tr class='tbl-tr'><td class='tbl-td' ></td> "
    #     for i in 0...6
    #       for j in 0...8
    #         @displayTimeTable +="<td class='tbl-td mg-table-heading mg-tbl-padding-mod' >#{periodTimingHash[j]}</td>"
    #       end
    #     end
    #     @displayTimeTable +="</tr> "

    #     displayTimeTableRow +="<tr class='tbl-tr'>"
    #     displayTimeTableRow +="<td class='tbl-td mg-tbl-cell-size mg-tbl-padding-mod' >#{batchName}</td>"

    #     @displayTimeTableWeekName +="<tr class='tbl-tr'><td class='tbl-td' ></td>"
    #     @displayTimeTableTiming   +="<tr class='tbl-tr'><td class='tbl-td' ></td>"
    #   end
      
    #   if checkBatch==testBatch
    #     # add the td in the tr 
    #     #displayTimeTableRow +="<td class='tbl-td' >#{weekDayName}-#{startTime}-#{endTime}-#{subjectName}
    #     #      -#{employeeName} </td>"
    #     displayTimeTableRow +="<td class='tbl-td mg-tbl-padding-mod mg-tbl-cell-size mg-tbl-bg-color-#{subjectName}' ><span class='mg-tbl-font-weight'>#{subjectName}</span><br/>#{employeeName}</td>"
    #     if count==1
    #       currentDay=testWeek
    #       #s_time=startTime
    #       #e_time=endTime
    #     end

    #     if weekDayName==testWeek
    #       count +=1
    #       currentDay=weekDayName
    #       @displayTimeTableTiming +="<td class='tbl-td mg-tbl-padding-mod mg-tbl-cell-size' >#{startTime}&nbsp;-#{endTime}</td>"
    #     else
    #       #currentDay=weekDayName
    #       @displayTimeTableWeekName +="<td class='tbl-td mg-tbl-padding-mod mg-tbl-cell-size' colspan='#{count}' >#{currentDay}</td>"

    #       @displayTimeTableTiming +="<td class='tbl-td mg-tbl-padding-mod mg-tbl-cell-size' >#{startTime}&nbsp;-#{endTime}</td>"
    #       count=0
    #       count +=1
    #       #s_time=startTime
    #       #e_time=endTime
    #     end

    #   else
    #     #close the tr if batch is change and add new tr for the
    #     #new batch
    #     displayTimeTableRow +="</tr>"

    #     @displayTimeTableWeekName +="<td class='tbl-td mg-tbl-padding-mod mg-tbl-cell-size' colspan='#{count}' >#{testWeek}</td>"
    #     @displayTimeTableWeekName +="</tr>"

    #     @displayTimeTableTiming +="</tr>"

    #     #@displayTimeTable +="<tr class='tbl-tr'><td class='tbl-td' colspan='#{count+1}' >#{weekDayName}</td></tr>"
    #     #@displayTimeTable += @displayTimeTableWeekName

    #     #@displayTimeTable +=@displayTimeTableWeekName
        
    #     #@displayTimeTable +=@displayTimeTableTiming
    #     @displayTimeTable += displayTimeTableRow

    #     displayTimeTableRow=""
    #     @displayTimeTableWeekName =""
    #     @displayTimeTableTiming=""

    #     displayTimeTableRow +="<tr class='tbl-tr'>"
    #     # displayTimeTableRow +="<td class='tbl-td' >#{batchName}</td><td class='tbl-td' >#{weekDayName}-#{startTime}-#{endTime}-#{subjectName}
    #     #     -#{employeeName} </td>"

    #      displayTimeTableRow +="<td class='tbl-td mg-tbl-padding-mod mg-tbl-cell-size' >#{batchName}</td><td class='tbl-td mg-tbl-padding-mod mg-tbl-cell-size mg-tbl-bg-color-#{subjectName}' ><span class='mg-tbl-font-weight'>#{subjectName}</span><br>#{employeeName} </td>"

    #     @displayTimeTableWeekName +="<tr class='tbl-tr'><td class='tbl-td' ></td>"
    #     @displayTimeTableTiming +="<tr class='tbl-tr'><td class='tbl-td' ></td>"
    #     @displayTimeTableTiming +="<td class='tbl-td mg-tbl-padding-mod mg-tbl-cell-size'>#{startTime}&nbsp;-#{endTime}</td>"
    #     count=0
    #     count +=1
    #   end

    #   testBatch=checkBatch
    #   testWeek=weekDayName
    #   #s_time=startTime
    #   #e_time=endTime

    # end

    # @displayTimeTableWeekName +="<td class='tbl-td mg-tbl-padding-mod mg-tbl-cell-size' colspan='#{count}' >#{testWeek}</td>"
    # @displayTimeTableWeekName +="</tr>"
    # @displayTimeTableTiming +="</tr>"
    # displayTimeTableRow +="</tr>"

    # #@displayTimeTable +=@displayTimeTableWeekName
    # #@displayTimeTable +=@displayTimeTableTiming
    # @displayTimeTable +=displayTimeTableRow
    # @displayTimeTable +="</table>"


  end




  def batches_for_selected_wing_in_classtimings
     @classId_for_selected_wing=MgCourse.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id],:mg_wing_id=>params[:mg_wing_id]).pluck(:id)
    @batches=MgBatch.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id],:mg_course_id=>@classId_for_selected_wing)
    
    render :layout => false
  end

 def class_timing_index
  #@class_id=MgCourse.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id],:mg_wing_id=>1).pluck(:id)
  #@batches = MgBatch.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id],:mg_course_id=>@class_id)
  @commonClassTimings=[]#MgClassTiming.where(:is_deleted=>0,:mg_wing_id=>nil,:mg_school_id=>session[:current_user_school_id])
  @schoolWings=MgWing.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:wing_name,:id)
  # puts "inside class_timings index"
  # puts @commonClassTimings.length.inspect
  # puts @commonClassTimings.inspect
 end

 def create_class_timing
  @allvalue=["0","1","2","3","4","5","6"]
  @wing_id=params[:mg_wing_id]
  if @wing_id==""
    @wing_id=nil
  else
    @wing_id=params[:mg_wing_id]
  end
  @weekdays=MgWeekday.where(:mg_wing_id=>@wing_id,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])

  render :layout => false
 end

 def save_class_timing
  MgClassTiming.transaction do
  @wing_id=params[:mg_wing_id]
  @checkedvalue=params[:checkedvalue]
  @checked_day=@checkedvalue.split(",")

  @checked_day.each do|checked|
    class_timings=MgClassTiming.new(ajax_create_params)
    class_timings.mg_weekday_id=checked
    @responcet = class_timings.save
    puts "from model"
    puts  @responcet
  end  

    if (!@responcet)
      respond_to do |format|
        format.json  { render :json => @responcet }
      end
    else
      respond_to do |format|
        format.json  { render :json => @responcet }
      end
    end
  end
 end

 def edit_class_timing
  @classtimings=MgClassTiming.find(params[:id])
  puts "class Timings"
  puts @classtimings.mg_batch_id.inspect
  puts @classtimings.mg_wing_id.inspect

  @weekDays=MgWeekday.where(:mg_wing_id=>@classtimings.mg_wing_id,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
  puts "week days"
  puts @weekDays[0].id.inspect
  @weekdayIds = MgClassTiming.where(:mg_wing_id=>@classtimings.mg_wing_id ,:name=> @classtimings.name,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:mg_weekday_id)
  puts "weekdayIds=="
  puts @weekdayIds
  #@weekdayIds = @weekdays.id

 
  #@weekdaycheckedforClass=MgWeekday.where(:id=> @weekdays.id, :is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:weekday)

  #puts "@weekdaycheckedforClass"
  #puts @weekdaycheckedforClass
  render :layout => false
 end

 def update_class_timing

  MgClassTiming.transaction do
  @wing_id=params[:mg_wing_id]
  @checked_week_day_value=params[:checkedWeekdayValue]
  @checked_week_day_edit=@checked_week_day_value.split(",")

  for i in 0...@checked_week_day_edit.size
      @classtimings=MgClassTiming.find(params[:id])
      #@dayTest=MgWeekday.where(:mg_batch_id=>@classtimings.mg_batch_id,:weekday=>@checked_week_day_edit[i])
       @checked_weekday_class_edit=MgClassTiming.where(:name=> @classtimings.name,:mg_weekday_id=> @checked_week_day_edit[i],:mg_wing_id=>@wing_id)
       
       if  @checked_weekday_class_edit.size < 1
       
          @checked_days=MgClassTiming.new
          @checked_days.mg_batch_id=@classtimings.mg_batch_id
          @checked_days.name=@classtimings.name
          @checked_days.start_time=params[:start_time]
          @checked_days.end_time=params[:end_time]
          @checked_days.is_break=params[:is_break]
          @checked_days.is_deleted=@classtimings.is_deleted
          @checked_days.mg_school_id=@classtimings.mg_school_id
          @checked_days.mg_weekday_id=@checked_week_day_edit[i]
          @checked_days.mg_wing_id=@wing_id
          @checked_days.save
     else
      @checked_weekday_class_edit[0].update(ajax_edit_params)
      end
  end
    

  @unchecked_week_day_value=params[:uncheckedWeekdayValue]
  @unchecked_week_day_edit=@unchecked_week_day_value.split(",")
  
  for i in 0...@unchecked_week_day_edit.size
       @uncheckedclasstimings=MgClassTiming.find(params[:id])
       @unchecked_weekday_for_edit_class=MgClassTiming.where(:name=> @uncheckedclasstimings.name,:mg_weekday_id=>@unchecked_week_day_edit[i],:mg_wing_id=>@wing_id)
        if @unchecked_weekday_for_edit_class.size>0
          @uncheckIsUpdated=@unchecked_weekday_for_edit_class[0].update(:is_deleted=>1)
        end
  end

  # puts "from model"
  # puts @checkIsSaved

  # puts "from model"
  # puts @checkIsUpdated

  # puts "from model"
  # puts @uncheckIsUpdated

    # if (!@checkIsSaved &&!@checkIsUpdated &&!@uncheckIsUpdated)
    #   puts "inside if"
    #     respond_to do |format|
    #       format.json  { render :json => @checkIsSaved }
    #     end
    # else
    #     puts "inside else"
    #     respond_to do |format|
    #       format.json  { render :json => @checkIsSaved }
    #     end
    # end
    end
 end

 def delete_class_timings
    @classtimings=MgClassTiming.find(params[:id])
    @classtimings.update(:is_deleted=>1)
 end

 def show_class_timings
  @wing_id=params[:mg_wing_id]
  if @wing_id==""
     @wing_id=nil
    else
      @wing_id=params[:mg_wing_id]
    end
     # @weekdaychecked=MgBatch.find(@wing_id).mg_weekdays.where(:is_deleted=>0).pluck(:weekday)
     #@commonClassTimings #= MgBatch.find(@wing_id).mg_weekdays.mg_class_timings.where(:is_deleted=>0)
     puts "inside show_class_timings"

   @commonClassTimings=MgClassTiming.where(:mg_wing_id=>@wing_id,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
  
   render :layout => false
 end

 def time_table_index
  @academicdetails=MgTimeTable.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).order("start_date ASC").paginate(page: params[:page], per_page: 10)
 end

 def create_time_table
  MgTimeTable.transaction do
   @time_table=MgTimeTable.new(create_time_table_params)
     @current_school = MgSchool.find(session[:current_user_school_id])
     @startDate = Date.strptime(params[:createTimeTable][:start_date],@current_school.date_format)
     @endDate   = Date.strptime(params[:createTimeTable][:end_date],@current_school.date_format)
    @time_table.update(:start_date => @startDate,:end_date => @endDate)
    @isSaved=@time_table.save
    puts "from model"
   puts @isSaved

   if(!@isSaved)
    puts "inside if"
     @object="Given date range overlaps with existing academic year."
  end
    redirect_to :action=>'time_table_index',:notice=>@object
  end
 
 end

 def new_time_table
    render :layout => false
 end

 def edit_time_table
  @acdameic_detail=MgTimeTable.find(params[:id])
  puts "inside edit time table"
  puts @acdameic_detail.inspect
  render :layout => false

 end

 def update_time_table
  MgTimeTable.transaction do
   @academic_detail_for_update=MgTimeTable.find(params[:id])
   @current_school = MgSchool.find(session[:current_user_school_id])
   @startDate = Date.strptime(params[:editTimeTable][:start_date],@current_school.date_format)
   @endDate   = Date.strptime(params[:editTimeTable][:end_date],@current_school.date_format)
  @isUpdated=@academic_detail_for_update.update(:name=>params[:editTimeTable][:name],:start_date => @startDate,:end_date => @endDate)
  #@academic_detail_for_update.update(edit_time_table_params)
   if(!@isUpdated)
      puts "inside if"
     @object="Given date range overlaps with existing academic year."
  end
   redirect_to :action=>'time_table_index',:notice=>@object
  end
 end

 def delete_time_table
   @academic_detail_for_delete=MgTimeTable.find(params[:id])
   @academic_detail_for_delete.update(:is_deleted=>1)
   #redirect_to :action=>'time_table_index'
   @academicdetails=MgTimeTable.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).paginate(page: params[:page], per_page: 10)
  render :layout => false
 end

  def time_table_associate_index
   #@academic_name=MgTimeTable.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name,:id)
    #@batch=MgBatch.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
    #@weekDays=MgClassTiming.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name,:id)
    
  end

  def batch_wise_select_class_timings_name
   
    @batch_id=params[:batch_id]
    wing_idArray=Array.new
    # if @batch_id==""
    #  @batch_id=nil
    # else
    #   @batch_id=params[:batch_id]
    # end

    #@batch_id = MgBatch.find(params[:batch_id])
     puts "================================mg-batch====================================="
     puts params[:batch_id]
     puts params
     puts @batch_id
     puts "================================mg-batch========================================"
    
    if @batch_id.present? 
      @wing_id=MgBatch.find(params[:batch_id]).mg_course.mg_wing_id        
     
      wing_idArray.push(@wing_id)
       @classTimingName=MgClassTiming.where(:mg_wing_id=>@wing_id,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id],:is_break=>0).pluck(:name, :id)
      @classTimingNameTable=MgClassTiming.where(:mg_wing_id=>@wing_id,:is_deleted=>0, :mg_school_id=>session[:current_user_school_id],:is_break=>0).order(:mg_weekday_id, :start_time)#.first(2)#, MgWeekday.find(:mg_weekday_id).weekday
       
       @SubjectIds = MgBatchSubject.where(:mg_batch_id=>@batch_id,:is_deleted=>0, :mg_school_id=>session[:current_user_school_id]).pluck(:mg_subject_id)
       @subject=MgSubject.where(:is_deleted=>0,:id=>@SubjectIds,:mg_school_id=>session[:current_user_school_id]).pluck(:subject_name,:id)

      @subject_type = MgSubjectType.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id],:created_by=>session[:user_id],:updated_by=>session[:user_id]).pluck(:name,:id)
      
      @employee=MgEmployee.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:first_name,:id)
      
      @mg_time_table_id=params[:mg_time_table_id]   
       render :layout => false    
    end
  end

  def batch_wise_week_day_time_table
    @name=params[:name]
    @weekDays=MgClassTiming.where(:id=>@name,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
    
    @subject=MgSubject.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:subject_name,:id)
    @employee=MgEmployee.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:first_name,:id)

    # @timetable=MgTimeTableEntry.where(:mg_class_timings_id=>@weekDays.id)


    render :layout => false
  end   

  def teacher_for_subject
    if params[:sub]=='Subject'
      sql="select b.first_name, b.id from mg_employee_subjects a, mg_employees b where a.mg_subject_id=#{params[:subject]} and a.mg_employee_id=b.id"
      @employee=MgEmployeeSubject.find_by_sql sql
      # puts "SubjectId"
      # puts params[:subject]
      # @employeeId=MgEmployeeSubject.where(:mg_subject_id=>params[:subject]).pluck(:mg_employee_id)
      # puts "EmployeeId"
      # puts @employeeId
      # @employee=MgEmployee.where(:id=>@employeeId).pluck(:first_name,:id)
      # puts "@employee"
      # puts @employee

      #validation for teachers start
      #@time_table_entry=MgTimeTableEntry.where(:mg_class_timings_id=>@mg_class_timings_id[i], :mg_weekday_id=>@weekdays[i], :is_deleted=>0, :mg_batch_id=>params[:batch], :mg_timetable_id=>params[:mg_time_table_id],:mg_school_id=>session[:current_user_school_id])
    
    end

    render :layout => false
  end

  def teacher_for_subject_save 
    puts"=============prms=================="
    puts params
    puts"=============prms==================" 
    @mg_time_table_id = params[:mg_time_table_id]
    @batch = params[:batch]    

    @elective_group_id = params[:elective_group_id]
    @elective_weekday_id = params[:elective_weekday_id]
    @elective_class_timings_id = params[:elective_class_timings_id]
    @elective_subject_id = params[:elective_subject_id]
    @elective_subject_teacher = params[:elective_subject_teacher]
    @elective_subject_type_id = params[:elective_subject_type_id]

    @mandatory_weekday_id = params[:mandatory_weekday_id]
    @mandatory_class_timings_id = params[:mandatory_class_timings_id]
    @mandatory_subject_id= params[:mandatory_subject_id]
    @mandatory_subject_teacher = params[:mandatory_subject_teacher]
    @mandatory_subject_type_id = params[:mandatory_subject_type_id]

    if @elective_subject_id.present?
      for i in 0...@elective_subject_id.size
        if @elective_subject_teacher[i].present?

          @table_entrys=MgTimeTableEntry.where(:mg_class_timings_id=>@elective_class_timings_id[i], :mg_weekday_id=>@elective_weekday_id[i], :is_deleted=>0, :mg_batch_id=>params[:batch], :mg_timetable_id=>params[:mg_time_table_id],:mg_school_id=>session[:current_user_school_id])
          @table_entrys.each do |table_entrys|
            @data1 = table_entrys.mg_subject_type_id
            @data2 = table_entrys.mg_elective_group_id
            if @data1==1
              table_entrys.update(:is_deleted=>1)
            elsif @data2.to_i != @elective_group_id[i].to_i              
              table_entrys.update(:is_deleted=>1)
            end          
          end          

          @time_table_entry=MgTimeTableEntry.where(:mg_subject_id=>@elective_subject_id[i], :mg_elective_group_id=>@elective_group_id[i], :mg_class_timings_id=>@elective_class_timings_id[i], :mg_weekday_id=>@elective_weekday_id[i], :is_deleted=>0, :mg_batch_id=>params[:batch], :mg_timetable_id=>params[:mg_time_table_id],:mg_school_id=>session[:current_user_school_id])
          if @time_table_entry.present?             
              #:mg_subject_id=>@elective_subject_id[i], :mg_elective_group_id=>@elective_group_id[i],
              @update=MgTimeTableEntry.find(@time_table_entry[0].id)
              @update.mg_employee_id=@elective_subject_teacher[i]
              @update.mg_subject_id=@elective_subject_id[i]
              @update.mg_elective_group_id=@elective_group_id[i]
              @update.save
          else
              @timetableentrie=MgTimeTableEntry.new(:mg_subject_type_id=>@elective_subject_type_id[i], :mg_elective_group_id=>@elective_group_id[i], :mg_batch_id=>params[:batch],:mg_class_timings_id=> @elective_class_timings_id[i],:mg_subject_id=>@elective_subject_id[i], :mg_employee_id=>@elective_subject_teacher[i],:mg_weekday_id=>@elective_weekday_id[i], :mg_timetable_id=>params[:mg_time_table_id], :is_deleted=>params[:is_deleted], :mg_school_id=>params[:mg_school_id],:created_by=>session[:user_id],:updated_by=>session[:user_id])
              @timetableentrie.save
          end
        end
      end
    end

    if @mandatory_subject_id.present?
      for i in 0...@mandatory_subject_id.size
        if @mandatory_subject_teacher[i].present?

          @mg_time_table=MgTimeTableEntry.where(:mg_class_timings_id=>@mandatory_class_timings_id[i], :mg_weekday_id=>@mandatory_weekday_id[i], :is_deleted=>0, :mg_batch_id=>params[:batch], :mg_timetable_id=>params[:mg_time_table_id],:mg_school_id=>session[:current_user_school_id])
          if @mg_time_table.size==1 
             @time_table_entry=MgTimeTableEntry.where(:mg_class_timings_id=>@mandatory_class_timings_id[i], :mg_weekday_id=>@mandatory_weekday_id[i], :is_deleted=>0, :mg_batch_id=>params[:batch], :mg_timetable_id=>params[:mg_time_table_id],:mg_school_id=>session[:current_user_school_id])
             if @time_table_entry.present?
                @update=MgTimeTableEntry.find(@time_table_entry[0].id)
                @update.mg_employee_id=@mandatory_subject_teacher[i]
                @update.mg_subject_id=@mandatory_subject_id[i]
                @update.save
              else
                @timetableentrie=MgTimeTableEntry.new(:mg_subject_type_id=>@mandatory_subject_type_id[i], :mg_batch_id=>params[:batch],:mg_class_timings_id=> @mandatory_class_timings_id[i],:mg_subject_id=>@mandatory_subject_id[i], :mg_employee_id=>@mandatory_subject_teacher[i],:mg_weekday_id=>@mandatory_weekday_id[i], :mg_timetable_id=>params[:mg_time_table_id], :is_deleted=>params[:is_deleted], :mg_school_id=>params[:mg_school_id])
                @timetableentrie.save
             end
          else            
            @mg_time_table.update_all(:is_deleted=>1)            
            @timetableentrie=MgTimeTableEntry.new(:mg_subject_type_id=>@mandatory_subject_type_id[i], :mg_batch_id=>params[:batch],:mg_class_timings_id=> @mandatory_class_timings_id[i],:mg_subject_id=>@mandatory_subject_id[i], :mg_employee_id=>@mandatory_subject_teacher[i],:mg_weekday_id=>@mandatory_weekday_id[i], :mg_timetable_id=>params[:mg_time_table_id], :is_deleted=>params[:is_deleted], :mg_school_id=>params[:mg_school_id],:created_by=>session[:user_id],:updated_by=>session[:user_id])
            @timetableentrie.save
          end
        end
      end
    end

      # @subject=params[:subject]
      # @employee=params[:employees]
      # @weekdays=params[:weekday_id]
      # @mg_class_timings_id=params[:mg_class_timings_id]
      # for i in 0...@employee.size        
      #   if @employee[i].present?
      #     @time_table_entry=MgTimeTableEntry.where(:mg_class_timings_id=>@mg_class_timings_id[i], :mg_weekday_id=>@weekdays[i], :is_deleted=>0, :mg_batch_id=>params[:batch], :mg_timetable_id=>params[:mg_time_table_id],:mg_school_id=>session[:current_user_school_id])
      #     if @time_table_entry.present?
      #       @update=MgTimeTableEntry.find(@time_table_entry[0].id)
      #       @update.mg_employee_id=@employee[i]
      #       @update.mg_subject_id=@subject[i]
      #       @update.save
      #     else
      #     @timetableentrie=MgTimeTableEntry.new(:mg_batch_id=>params[:batch],:mg_class_timings_id=> @mg_class_timings_id[i],:mg_subject_id=>@subject[i], :mg_employee_id=>@employee[i],:mg_weekday_id=>@weekdays[i], :mg_timetable_id=>params[:mg_time_table_id], :is_deleted=>params[:is_deleted], :mg_school_id=>params[:mg_school_id])
      #     @timetableentrie.save
      #     end
      #   end
      # end
     redirect_to :action=>'index'
  end

  def view_time_table_index
    @course=MgCourse.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:course_name,:id)
    @batch=MgBatch.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name,:id)
  end

  def batch_for_selected_course
    if params[:course_id]!=""
      @courseID=params[:course_id]
      @batches=MgBatch.where(:mg_course_id=>@courseID,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name,:id)
       @courses=MgCourse.where(:id=>@courseID,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
       @batch=Array.new
       @courses.each do |batches|
          batches.mg_batches.each do |batch|
             @batchName=Array.new
            @batchName.push(batch.name)
            @batch.push(@batchName)
          end
       end
       render :layout => false
     else
      render :layout => false
    end
  end
  def batch_wise_view_time_table
    @wing_id=params[:batch_id]
    @courseId=params[:course_id]
    @courseName=MgCourse.where(:id=> @courseId,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:course_name).join("")
    @batchname=MgBatch.where(:id=>@wing_id,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name).join("")
    @weekDayForSelectedBatch=MgTimeTableEntry.where(:mg_batch_id=>@wing_id,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
    puts "weekday for selected batch"
    puts @weekDayForSelectedBatch.inspect
    render :layout => false
  end

  def day_wise_view_time_table
    @wing_id=params[:batch_id]
    @courseId=params[:course_id]
    @weekdayId=params[:day_id]
    @courseName=MgCourse.where(:id=> @courseId,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:course_name).join("")
    @batchname=MgBatch.where(:id=>@wing_id,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name).join("")
    @weekDayForSelectedBatch=MgTimeTableEntry.where(:mg_batch_id=>@wing_id,:is_deleted=>0,:mg_weekday_id=>@weekdayId,:mg_school_id=>session[:current_user_school_id])
    render :layout => false
  end

 

  def change_teacher_index
    @acadamic_year= MgTimeTable.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name,:id)
    @batch_name=MgBatch.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name,:id)
    @subject=MgSubject.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:subject_name,:id)
    @employee=MgEmployee.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:first_name,:id)
    @period=MgClassTiming.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name,:id)
  end

  def class_timings_for_selected_batch
    @period=MgClassTiming.where(:mg_batch_id=>params[:batch_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:name,:id)
    render :layout => false
  end

  def teacher_for_selected_subject
    @employeesId=MgEmployeeSubject.where(:mg_subject_id=>params[:subjectId],:mg_school_id=>session[:current_user_school_id])
    @keyAndValue=Array.new
    @employeesId.each do |emp|
        @employee=Array.new
        @employee.push(emp.mg_employee.first_name) 
        @employee.push(emp.mg_employee.id) 
        @keyAndValue.push(@employee)
     end
     render :layout => false
  end

  def select_batch_for_show_time_table

   
    
    #@wing_id = MgBatch.find(params[:batch_id]).mg_course.mg_wing_id
    if params[:batch_id]!=""

      @academic_years  =   MgTimeTable.where("start_date < \"#{Date.today}\" && \"#{Date.today}\" < end_date").where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
      puts @academic_years.inspect
      @timetables

      @timetables=MgTimeTableEntry.where(:mg_batch_id=>params[:batch_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])

      # unless( @academic_years.nil?)
      #   if( @academic_years.length>0)
      #     @timetables=MgTimeTableEntry.where(:mg_timetable_id=>@academic_years[0].id,:mg_batch_id=>params[:batch_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
      #       puts @timetables.inspect
            
      #   end
      # end
    
    render :layout => false
  else
    @data="data is empty"
    render :layout => false
  end
    
  end
  def view_employee_time_table_index
    @department=MgEmployeeDepartment.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck( :department_name, :id)

  end

  def all_employee_for_time_table
    @employee=MgEmployee.where(:mg_employee_department_id=>params[:mg_employee_department_id], :is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:first_name, :id)
    render :layout => false    
  end
  def employee_time_table
     @academic_years  =   MgTimeTable.where("start_date < \"#{Date.today}\" && \"#{Date.today}\" < end_date").where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
     puts "academicdetails for employee"
     puts @academic_years.inspect
     #logger.infoazxckh
     @timetables=MgTimeTableEntry.where(:mg_employee_id=>params[:mg_employee_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])

    #  if @academic_years.size>0
    #     @timetables=MgTimeTableEntry.where(:mg_timetable_id=>@academic_years[0].id,:mg_employee_id=>params[:mg_employee_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
    # else
    #   @timetables=MgTimeTableEntry.new
    # end
    render :layout => false    
  end
  def view_subject_time_table
    @subject=MgSubject.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:subject_code,:id)

  end

  def view_subject_time_table_index
     @academic_years  =   MgTimeTable.where("start_date < \"#{Date.today}\" && \"#{Date.today}\" < end_date").where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
     puts "academicdetails for employee"
     puts @academic_years.length

     @timetables=MgTimeTableEntry.where(:mg_subject_id=>params[:mg_subject_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
    #  if @academic_years.length>0
    #   @timetables=MgTimeTableEntry.where(:mg_timetable_id=>@academic_years[0].id,:mg_subject_id=>params[:mg_subject_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
    # else
    #   @timetables=MgTimeTableEntry.new
    # end
      render :layout => false
    
  end
  def view_free_teachers_time_table
    sql="select distinct a.id from mg_employees a, mg_time_table_entries b, mg_employee_categories c where not(a.id=b.mg_employee_id) and a.is_deleted=0 and b.is_deleted=0 and a.mg_employee_category_id=(SELECT id FROM mg_employee_categories where category_name='Teaching Staff');"
    @freeEmployee=MgEmployee.find_by_sql sql

    #@period=MgClassTiming.where(:is_deleted=>0).pluck(:name, :id)
  #shr
    @period=MgClassTiming.where(:is_deleted=>0,:is_break=>0,:mg_school_id=>session[:current_user_school_id]).group(:name).pluck(:name)
  end

def absent_teachers

  @absent_teachers=MgEmployeeAttendance.where(:mg_school_id=>session[:current_user_school_id],:absent_date=>DateTime.now.strftime('%Y-%m-%d'))
  
end
def show_free_teacher
  #@timetables=MgTimeTableEntry.where(:mg_class_timings_id=>params[:class_time_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
  #@freeTeacher=MgTimeTableEntry.where(:mg_class_timings_id=>params[:class_time_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:mg_employee_id)
 @academic_years  =   MgTimeTable.where("start_date < \"#{Date.today}\" && \"#{Date.today}\" < end_date").where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
     puts "academicdetails for employee"
     puts @academic_years.length

  @mg_class_timings = MgClassTiming.where(:name=>params[:class_time_name],:mg_school_id=>session[:current_user_school_id]).pluck(:id)
  
 #  if(@academic_years.length>0)
 #    @timetables=MgTimeTableEntry.where(:mg_timetable_id=>@academic_years[0].id,:mg_class_timings_id=>@mg_class_timings,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
 #    @occupiedTeacher=MgTimeTableEntry.where(:mg_timetable_id=>@academic_years[0].id,:mg_class_timings_id=>@mg_class_timings,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:mg_employee_id)
 #    @free_teacher = MgEmployee.where(:is_deleted=>0,:mg_employee_category_id=>1,:mg_school_id=>session[:current_user_school_id])
 #    @free_teacher = MgEmployee.where(:is_deleted=>0,:mg_employee_category_id=>1,:mg_school_id=>session[:current_user_school_id]).where('id not in (?)',@occupiedTeacher) unless @occupiedTeacher.empty?
 # else
 #  @timetables=MgTimeTableEntry.new
 # end

@timetables=MgTimeTableEntry.where(:mg_class_timings_id=>@mg_class_timings,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
@occupiedTeacher=MgTimeTableEntry.where(:mg_class_timings_id=>@mg_class_timings,:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:mg_employee_id)
@free_teacher = MgEmployee.where(:is_deleted=>0,:mg_employee_category_id=>1,:mg_school_id=>session[:current_user_school_id])
#@free_teacher = MgEmployee.where(:is_deleted=>0,:mg_employee_category_id=>1,:mg_school_id=>session[:current_user_school_id]).where('id not in (?)',@occupiedTeacher) unless @occupiedTeacher.empty?

  #@employee=MgEmployee.where(:is_deleted=>0,:mg_employee_category_id=>1,:mg_school_id=>session[:current_user_school_id]).pluck(:id)
   # @all_employee=MgEmployee.where(:is_deleted=>0,:mg_employee_category_id=>1,:mg_school_id=>session[:current_user_school_id] ).pluck(:id)
  
 #for i in 0...@freeTeacher.size
  
  #@employee.delete(@freeTeacher[i]) 
 #end


 puts @timetables.inspect

  render :layout => false
  
end
def batches_for_selected_wing
  @classId_for_selected_wing=MgCourse.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id],:mg_wing_id=>params[:mg_wing_id]).pluck(:id)
  @batches=MgBatch.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id],:mg_course_id=>@classId_for_selected_wing)
  render :layout => false
end

def generate_timetable
school_id = session[:current_user_school_id]
  @notice = ""
 begin
   gtt = TimeTableGenerator.new

   @notice = gtt.create_time_table(school_id)
  rescue Exception => ex
    @notice ="Error occured, please contact administrator"
 end

   puts "After resue"
     render :json=>{:notice=>@notice}
end  

def generate_timetable_2

  school_id = session[:current_user_school_id]

gtt = TimeTableGenerator.new

gtt.create_time_table(school_id)


redirect_to :action=>'time_table_creation' and return
end


def generate_timetable_1



@timetable_generate=MgTimeTableEntry.all

@timetable_generate.each do |timetable|

timetable.update(:is_deleted => 0)


  end
  puts"generate_timetable"
  @timetable_generate

  redirect_to :back
end

def delete_timetable


@timetabledelete=MgTimeTableEntry.all

@timetabledelete.each do |timetable|

timetable.update(:is_deleted => 1)


  end


#   puts "8888888888888888888"
#   # @timetable=MgTimeTableEntry.all
#   # @timetable.destroy
# MgTimeTableEntry.where("id > 0").delete_all
#   #MgTimeTableEntry.delete_all("id > 0")
#   puts "88888888888888888888"
  redirect_to :back
end

def mandatory_subject_list
 #if request.xhr?
   @subjects = MgSubject.where(:mg_subject_type_id=>params[:subject_type_id],:is_deleted=>0).pluck(:subject_name,:id)
   @weekday_id_list = params[:weekday_id_list]
   @mg_class_timings_id=params[:mg_class_timings_id]
   @mg_time_table_id = params[:mg_time_table_id]
   @subject_type_id = params[:subject_type_id]
   render :layout => false
   #render :json=>{:subject_list=>@subject}
  #end
end

def elective_subject_type 
  @elective_group = MgElectiveGroup.where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id],:created_by=>session[:user_id],:updated_by=>session[:user_id]).pluck(:name,:id)
  @weekday_id_list = params[:weekday_id_list]
  @mg_class_timings_id=params[:mg_class_timings_id]
  @batch_id = params[:batch_id]
  @mg_time_table_id=params[:mg_time_table_id]
  @subject_type_id = params[:subject_type_id]
  render :layout => false
end

def elective_subjects
  @subject = MgSubject.where(:mg_elective_group_id=>params[:elective_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])#.pluck(:subject_name,:id)
  @weekday_id_list = params[:weekday_id_list]
  @mg_class_timings_id=params[:mg_class_timings_id]
  @elective_group_id = params[:elective_id]
  @subject_type_id = params[:subject_type_id]
  render :layout=> false
end

def elective_employee_list    
  @elective_subject = MgSubject.where(:mg_elective_group_id=>params[:elective_group_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])#.pluck(:subject_name,:id)
  @weekday_id_list = params[:weekday_id_list]
  @mg_class_timings_id=params[:mg_class_timings_id]
  @elective_group_id=params[:elective_group_id]
  @batch_id = params[:batch_id]
  @mg_time_table_id=params[:mg_time_table_id]  
  render :layout=> false
end

def mandatory_subject   
  array = []
  @mg_employee_id = MgEmployeeSubject.where(:mg_subject_id=>params[:subject_id],:is_deleted=>0,:mg_school_id=>session[:current_user_school_id]).pluck(:mg_employee_id)
  if @mg_employee_id.present?
    for i in 0...@mg_employee_id.size
      @time_table_entry=MgTimeTableEntry.where(:mg_employee_id=>@mg_employee_id[i],:mg_class_timings_id=>params[:mg_class_timings_id], :mg_weekday_id=>params[:weekday_id_list], :is_deleted=>0, :mg_timetable_id=>params[:mg_time_table_id],:mg_school_id=>session[:current_user_school_id]) 
      if !@time_table_entry.present?
        array.push(@mg_employee_id[i])
      end
    end
  end
  @array_id= array
  @mg_employee = MgEmployee.where(:is_deleted=>0,:mg_school_id=>1).where("id IN(?)",@array_id).pluck(:first_name,:id)
  render :layout=> false  
end

def batch_list  
  @academic_year_id = params[:academic_year_id]
  @academic_name = MgTimeTable.find_by(:id=>params[:academic_year_id])
  @academic_name.start_date
  @academic_name.end_date
  @batch_name =MgBatch.where("start_date >=? and start_date <=? and end_date <=?",@academic_name.start_date,@academic_name.end_date,@academic_name.end_date).where(:is_deleted=>0,:mg_school_id=>session[:current_user_school_id])
  render :layout=>false
end


 private 
 def teacher_for_subject_params
    params.require(:createtimetableasso).permit(:mg_batch_id, :mg_weekday_id, :mg_class_timings_id, :mg_subject_id, :mg_employee_id, :is_deleted)
 end
 def create_time_table_params
  params.require(:createTimeTable).permit(:start_date,:end_date,:is_deleted,:name,:mg_school_id)
 end

 def edit_time_table_params
  params.require(:editTimeTable).permit(:start_date,:end_date,:is_deleted,:name,:mg_school_id)
 end

 def ajax_create_params
    params.permit(:name,:start_time,:end_time,:is_break,:is_deleted,:mg_batch_id,:mg_school_id,:mg_wing_id)
 end

 def ajax_edit_params
    params.permit(:name,:start_time,:end_time,:is_break,:is_deleted,:mg_batch_id,:mg_school_id,:mg_wing_id)
 end

end